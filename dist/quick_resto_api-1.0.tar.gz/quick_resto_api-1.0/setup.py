from setuptools import setup

setup(
    name="quick_resto_api", 
    version="1.0",
    description='Quick Resto API',
    packages=['quick_resto_api'],
    author_email='sergey.rukin1425@gmail.com',
    )